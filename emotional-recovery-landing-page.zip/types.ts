import React from 'react';

export interface FAQItem {
  question: string;
  answer: string;
}

export interface BulletPoint {
  title: string;
  description: string;
}

export interface Benefit {
  icon: React.ReactNode;
  text: string;
}