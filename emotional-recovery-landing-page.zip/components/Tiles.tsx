import React, { useEffect, useState, useMemo } from 'react';

export const Tiles: React.FC = () => {
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });

  useEffect(() => {
    const handleResize = () => {
      setDimensions({
        width: window.innerWidth,
        height: window.innerHeight
      });
    };

    handleResize();
    
    // Debounce resize to prevent excessive calculations
    let timeoutId: number;
    const debouncedResize = () => {
      clearTimeout(timeoutId);
      timeoutId = window.setTimeout(handleResize, 100);
    };

    window.addEventListener('resize', debouncedResize);
    return () => window.removeEventListener('resize', debouncedResize);
  }, []);

  const { cols, rows, tiles } = useMemo(() => {
    const TILE_SIZE = 80; 
    if (dimensions.width === 0) return { cols: 0, rows: 0, tiles: [] };
    const c = Math.ceil(dimensions.width / TILE_SIZE);
    const r = Math.ceil(dimensions.height / TILE_SIZE);
    
    const t = [];
    for (let i = 0; i < c; i++) {
      for (let j = 0; j < r; j++) {
        t.push({
          id: `${i}-${j}`,
          x: i,
          y: j,
        });
      }
    }

    return { cols: c, rows: r, tiles: t };
  }, [dimensions]);

  if (dimensions.width === 0) return null;

  return (
    <div 
      className="fixed inset-0 z-0 pointer-events-none overflow-hidden"
      style={{
        display: 'grid',
        gridTemplateColumns: `repeat(${cols}, 1fr)`,
        gridTemplateRows: `repeat(${rows}, 1fr)`,
      }}
    >
      {tiles.map((tile) => (
        <div 
          key={tile.id}
          className="border-[0.5px] border-slate-900/[0.03] transition-all hover:bg-slate-900/[0.05]"
        />
      ))}
    </div>
  );
};