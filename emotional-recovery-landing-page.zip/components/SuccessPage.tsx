import React, { useState } from 'react';
import { jsPDF } from "jspdf";
import { Download, CheckCircle, ArrowLeft } from 'lucide-react';
import { Button } from './Button';
import { bookContent, bookTitle, bookSubtitle } from '../data/bookContent';

export const SuccessPage: React.FC = () => {
  const [isGenerating, setIsGenerating] = useState(false);

  const generateAndDownloadPDF = () => {
    setIsGenerating(true);
    
    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();
      const margin = 20;
      const maxLineWidth = pageWidth - (margin * 2);
      let yPosition = 30;

      // --- Title Page ---
      doc.setFont("times", "bold");
      doc.setFontSize(24);
      
      // Split title to fit
      const titleLines = doc.splitTextToSize(bookTitle, maxLineWidth);
      doc.text(titleLines, pageWidth / 2, 80, { align: "center" });

      doc.setFontSize(14);
      doc.setFont("times", "italic");
      doc.text(bookSubtitle, pageWidth / 2, 110, { align: "center" });
      
      doc.setFontSize(12);
      doc.setFont("times", "normal");
      doc.text("Immediate Digital Access Copy", pageWidth / 2, 130, { align: "center" });

      // Add a page break for content
      doc.addPage();
      yPosition = 30;

      // --- Content Pages ---
      bookContent.forEach((section) => {
        // Check if we need a new page for the title
        if (yPosition > 250) {
          doc.addPage();
          yPosition = 30;
        }

        // Section Title
        doc.setFont("times", "bold");
        doc.setFontSize(16);
        doc.text(section.title, margin, yPosition);
        yPosition += 15;

        // Section Body
        doc.setFont("times", "normal");
        doc.setFontSize(12);
        
        // Split text to wrap
        const bodyLines = doc.splitTextToSize(section.text, maxLineWidth);
        
        // Loop through lines to check for page breaks
        bodyLines.forEach((line: string) => {
          if (yPosition > 270) {
            doc.addPage();
            yPosition = 30;
          }
          doc.text(line, margin, yPosition);
          yPosition += 7;
        });

        // Add extra space after section
        yPosition += 15;
      });

      doc.save("The_Cure_Protocol.pdf");
    } catch (error) {
      console.error("Error generating PDF:", error);
      alert("There was an error generating your PDF. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-64 bg-slate-900 z-0"></div>
      
      <div className="bg-white max-w-2xl w-full rounded-2xl shadow-xl relative z-10 p-8 md:p-12 text-center">
        <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-8 animate-bounce">
          <CheckCircle className="w-10 h-10 text-emerald-600" />
        </div>
        
        <h1 className="text-3xl font-serif font-bold text-slate-900 mb-4">
          Payment Successful
        </h1>
        
        <p className="text-lg text-slate-600 mb-8">
          Thank you for investing in yourself. Your protocol is ready.
        </p>

        <div className="bg-slate-50 border border-slate-200 rounded-lg p-6 mb-8 text-left">
          <div>
            <h3 className="font-bold text-slate-900 text-lg">The Cure Protocol</h3>
            <p className="text-sm text-slate-500 mb-3">Digital PDF Edition • 11 Pages</p>
            <p className="text-sm text-slate-600 leading-snug">
              This document contains the complete step-by-step emotional recovery guide.
              Click the button below to save it to your device immediately.
            </p>
          </div>
        </div>

        <Button 
          onClick={generateAndDownloadPDF} 
          fullWidth
          className="flex items-center justify-center gap-2 py-4 mb-4"
          disabled={isGenerating}
        >
          {isGenerating ? 'Generating PDF...' : 'Download PDF Now'}
          {!isGenerating && <Download className="w-5 h-5" />}
        </Button>

        <p className="text-xs text-slate-400 mt-6">
          If your download doesn't start automatically, please refresh the page.
        </p>
        
        <div className="mt-8 pt-8 border-t border-slate-100">
          <a href="/" className="text-slate-500 text-sm hover:text-slate-900 flex items-center justify-center gap-2">
            <ArrowLeft className="w-4 h-4" />
            Return to Homepage
          </a>
        </div>
      </div>
    </div>
  );
};