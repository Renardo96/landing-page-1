import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Button } from './Button';
import { AlertCircle, ArrowRight, BrainCircuit, CheckCircle2 } from 'lucide-react';

export const AIPreview: React.FC = () => {
  const [input, setInput] = useState('');
  const [response, setResponse] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!input.trim()) return;
    
    setLoading(true);
    setError(null);
    setResponse(null);

    try {
      const apiKey = process.env.API_KEY;
      if (!apiKey) {
        throw new Error("API Key not found");
      }

      const ai = new GoogleGenAI({ apiKey });
      const result = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `
          User Input: "${input}"
          
          Task: You are the AI companion for the book "The Cure for Missing Someone Who Doesn’t Miss You". 
          The user is struggling with an obsessive thought about an ex-partner or unrequited love.
          Provide a 2-sentence "Stoic Reframing" based on the book's core philosophy:
          1. Emotional detachment without coldness.
          2. Pulling energy back to oneself.
          3. Viewing the situation with calm logic, not panic.
          
          Do not offer therapy. Do not offer platitudes like "it will get better". 
          Instead, offer a perspective shift that empowers the user to stop caring right now.
          Keep it simple (7th-grade reading level).
          
          Format: Just the text. No intro.
        `,
      });

      setResponse(result.text || "Could not generate a response. Please try again.");
    } catch (err) {
      setError("Unable to connect to the clarity engine. Please try again later.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="py-16 bg-slate-50 border-y border-slate-200">
      <div className="max-w-2xl mx-auto px-6">
        <div className="flex items-center gap-3 mb-6">
          <BrainCircuit className="w-8 h-8 text-slate-700" />
          <h2 className="text-2xl font-serif font-bold text-slate-900">
            See How The Protocol Works
          </h2>
        </div>
        
        <p className="text-slate-600 mb-8">
          Type a thought that keeps hurting you (e.g., "I keep checking if they viewed my story"). 
          The engine will give you a sample reframing from the book to help you detach instantly.
        </p>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ex: I feel weak because I texted them again..."
            className="w-full p-4 border border-slate-300 rounded mb-4 focus:outline-none focus:ring-2 focus:ring-slate-500 h-24 resize-none text-slate-900 placeholder:text-slate-400"
          />
          
          <Button 
            onClick={handleGenerate} 
            disabled={loading || !input.trim()}
            fullWidth
            className="flex justify-center items-center gap-2"
          >
            {loading ? 'Reframing...' : 'Get Instant Clarity'}
            {!loading && <ArrowRight className="w-5 h-5" />}
          </Button>

          {error && (
            <div className="mt-4 p-4 bg-red-50 text-red-800 rounded flex items-center gap-2 border border-red-100">
              <AlertCircle className="w-5 h-5" />
              {error}
            </div>
          )}

          {response && (
            <div className="mt-6 p-6 bg-slate-50 border-l-4 border-slate-800 rounded animate-fade-in">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-6 h-6 text-slate-800 mt-1 shrink-0" />
                <div>
                  <h4 className="font-bold text-slate-900 text-sm uppercase tracking-wide mb-2">Protocol Perspective</h4>
                  <p className="text-slate-800 text-lg leading-relaxed font-serif italic">
                    "{response}"
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};