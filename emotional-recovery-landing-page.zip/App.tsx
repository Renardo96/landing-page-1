import React, { useEffect, useState } from 'react';
import { BookOpen, Check, Shield, Clock, Brain, Lock, Menu, X } from 'lucide-react';
import { Button } from './components/Button';
import { AIPreview } from './components/AIPreview';
import { Tiles } from './components/Tiles';
import { SuccessPage } from './components/SuccessPage';

function App() {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  useEffect(() => {
    // Check for PayPal return URL parameter
    const params = new URLSearchParams(window.location.search);
    if (params.get('success') === 'true') {
      setIsSuccess(true);
    }
  }, []);

  // Construct the return URL for PayPal
  const returnUrl = encodeURIComponent(window.location.origin + window.location.pathname + '?success=true');
  
  // PayPal Parameters:
  const PAYMENT_LINK = `https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=renardo.palmer12@gmail.com&currency_code=USD&amount=7.00&item_name=The%20Cure%20Protocol%20-%20Digital%20Book&return=${returnUrl}&rm=1&cbt=Return%20to%20Download%20Book`;

  const scrollToPurchase = () => {
    document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' });
  };

  if (isSuccess) {
    return (
      <div className="min-h-screen font-sans text-slate-900 selection:bg-slate-200 relative">
        <Tiles />
        <SuccessPage />
      </div>
    );
  }

  return (
    <div className="min-h-screen font-sans text-slate-900 selection:bg-slate-200 relative">
      
      {/* Background Tiles Animation */}
      <Tiles />

      {/* Navigation - Minimal */}
      <nav className="fixed w-full bg-white/90 backdrop-blur-md border-b border-slate-200 z-50">
        <div className="max-w-5xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="font-serif font-bold text-lg tracking-tight text-slate-900">The Cure Protocol</div>
          <button 
            className="md:hidden text-slate-800"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X /> : <Menu />}
          </button>
          <div className="hidden md:block">
            <Button onClick={scrollToPurchase} variant="primary" className="py-2 px-4 text-sm bg-slate-900 hover:bg-slate-800">
              Get Instant Access
            </Button>
          </div>
        </div>
      </nav>

      {/* 1. HERO SECTION */}
      <header className="pt-32 pb-16 px-6 max-w-3xl mx-auto text-center relative z-10">
        <h1 className="text-4xl md:text-6xl font-serif font-bold leading-tight mb-6 text-slate-900">
          The Cure for Missing Someone Who Doesn’t Miss You
        </h1>
        <p className="text-xl md:text-2xl text-slate-700 mb-10 leading-relaxed font-medium">
          A fast emotional recovery protocol for people who are mentally stuck on someone who’s already gone — and paying for it with anxiety, obsession, and quiet self-destruction.
        </p>

        {/* Book Cover Visual */}
        <div className="mb-12 flex justify-center">
            <div className="relative group cursor-default inline-block">
              {/* Glow effect behind the book */}
              <div className="absolute -inset-4 bg-white/40 rounded-xl blur-xl group-hover:bg-white/60 transition duration-500"></div>
              
              {/* CSS Book Cover with Photographic Background */}
              <div className="relative w-64 md:w-72 aspect-[2/3] rounded-r-md rounded-l-sm shadow-2xl shadow-slate-900/40 transform -rotate-2 group-hover:rotate-0 group-hover:-translate-y-2 transition-all duration-500 ease-out flex flex-col overflow-hidden border-l-2 border-slate-700 bg-slate-900">
                
                {/* Background Image */}
                <div className="absolute inset-0">
                  <img 
                    src="https://images.unsplash.com/photo-1518173946687-a4c8892bbd9f?q=80&w=800&auto=format&fit=crop" 
                    alt="Cover Texture" 
                    className="w-full h-full object-cover opacity-80"
                  />
                  {/* Overlays for text readability */}
                  <div className="absolute inset-0 bg-slate-900/50 mix-blend-multiply"></div>
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/40 to-slate-900/30"></div>
                </div>
                
                {/* Content */}
                <div className="relative z-10 flex flex-col h-full justify-between p-8 text-center">
                  <div>
                    <div className="uppercase tracking-[0.2em] text-slate-300 text-[10px] mb-8 font-semibold drop-shadow-md">The Cure Protocol</div>
                    <h3 className="font-serif font-bold text-4xl text-white leading-none mb-4 tracking-tight drop-shadow-lg">The<br/>Cure</h3>
                    <div className="w-12 h-0.5 bg-emerald-500 mx-auto mb-4 shadow-[0_0_10px_rgba(16,185,129,0.5)]"></div>
                    <p className="font-serif text-slate-200 italic text-sm leading-tight px-2 drop-shadow-md">For Missing Someone Who Doesn’t Miss You</p>
                  </div>
                  
                  <div className="flex justify-center mt-auto">
                    <div className="w-12 h-12 rounded-full border border-slate-400/30 flex items-center justify-center bg-white/10 backdrop-blur-sm shadow-inner">
                      <Brain className="w-6 h-6 text-emerald-400" />
                    </div>
                  </div>
                </div>

                {/* Spine Highlight */}
                <div className="absolute left-0 top-0 bottom-0 w-2 bg-gradient-to-r from-white/20 to-transparent z-20"></div>
                <div className="absolute right-0 top-0 bottom-0 w-1 bg-gradient-to-l from-black/40 to-transparent z-20"></div>
              </div>
            </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Button onClick={scrollToPurchase} className="w-full sm:w-auto shadow-xl bg-slate-900 text-white hover:bg-slate-800">
            Get Instant Access
          </Button>
        </div>

        <div className="mt-6 flex justify-center items-center gap-2">
          <span className="text-xs text-slate-500 font-medium uppercase tracking-wide opacity-90">Secured by</span>
          <img 
            src="https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg" 
            alt="PayPal" 
            className="h-6 bg-white border border-slate-200 rounded px-2 py-1 shadow-sm"
          />
        </div>

        <p className="mt-4 text-sm text-slate-500 font-medium">Digital Book • Instant Download</p>
      </header>

      {/* 2. IDENTIFICATION SECTION */}
      <section className="py-16 bg-white/50 border-y border-slate-200 shadow-sm relative z-10">
        <div className="max-w-2xl mx-auto px-6">
          <h2 className="text-sm font-bold uppercase tracking-widest text-slate-500 mb-8 text-center">
            Does this sound like your life right now?
          </h2>
          <div className="space-y-6">
            {[
              "You still care more than they do.",
              "You know it’s over… but your mind won’t let go.",
              "You feel weak for missing someone who doesn’t miss you.",
              "You check their social media, looking for clues that don't exist.",
              "You replay old conversations, searching for where it went wrong."
            ].map((item, i) => (
              <div key={i} className="flex items-start gap-4 p-4 bg-white rounded-lg shadow-sm border border-slate-100">
                <div className="bg-red-50 text-red-900 p-1 rounded mt-1">
                  <X className="w-4 h-4" />
                </div>
                <p className="text-lg text-slate-800">{item}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 3. THE REAL PROBLEM */}
      <section className="py-20 px-6 max-w-3xl mx-auto relative z-10">
        <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl p-8 md:p-12 border border-slate-200/50">
          <h2 className="text-3xl font-serif font-bold mb-8 text-center text-slate-900">
            Why You Can’t "Just Stop"
          </h2>
          <div className="prose prose-lg mx-auto text-slate-700 leading-relaxed">
            <p className="mb-6">
              Everyone tells you to "give it time" or "keep busy."
            </p>
            <p className="mb-6">
              But distraction doesn't work. Logic doesn't work. You already <em>know</em> they aren't right for you, but you still feel the pull.
            </p>
            <p className="mb-6 font-semibold">
              The problem isn't that you're weak. The problem is that you are fighting an emotional addiction with willpower.
            </p>
            <div className="my-10 p-6 bg-slate-100 text-slate-800 rounded-lg text-center shadow-inner border border-slate-200">
              <p className="text-xl font-serif italic text-slate-900">
                "Your mind keeps reopening the wound like picking a scab — this book shows you how to stop touching it."
              </p>
            </div>
            <p>
              When you try to force yourself to stop caring, you actually focus <em>more</em> on the feeling. You create a feedback loop of obsession.
            </p>
          </div>
        </div>
      </section>

      {/* 4. THE SOLUTION */}
      <section className="py-20 bg-slate-50 px-6 relative z-10 border-t border-slate-200">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-serif font-bold mb-6 text-center text-slate-900">
            Not Therapy. Not Positive Thinking. <br/>
            <span className="text-slate-500">Emotional First Aid.</span>
          </h2>
          <div className="text-lg text-slate-700 mb-8 space-y-6">
            <p>
              This is a step-by-step emotional recovery protocol. It is designed to be read in one sitting and applied immediately.
            </p>
            <p>
              We use principles of Stoicism and cognitive reframing to help you manually override the "missing" instinct.
            </p>
          </div>
          
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
            <ul className="space-y-4">
              <li className="flex items-center gap-3 font-medium text-lg text-slate-800">
                <Check className="w-6 h-6 text-emerald-700 flex-shrink-0" />
                Emotional detachment without becoming cold
              </li>
              <li className="flex items-center gap-3 font-medium text-lg text-slate-800">
                <Check className="w-6 h-6 text-emerald-700 flex-shrink-0" />
                Calm control, not suppression
              </li>
              <li className="flex items-center gap-3 font-medium text-lg text-slate-800">
                <Check className="w-6 h-6 text-emerald-700 flex-shrink-0" />
                Pulling energy back instead of fighting feelings
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* AI INTERACTIVE SECTION */}
      <div className="relative z-10">
        <AIPreview />
      </div>

      {/* 5. WHAT YOU'LL LEARN */}
      <section className="py-20 px-6 bg-slate-900 text-slate-50 relative z-10">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-serif font-bold mb-12 text-center text-slate-100">What Happens When You Use This Protocol</h2>
          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                title: "Regain Emotional Control",
                desc: "Stop the spiral of panic and anxiety when you think of them."
              },
              {
                title: "Stop Obsessive Thoughts",
                desc: "Learn the 'Stop-Reset' technique to clear your mind instantly."
              },
              {
                title: "Pull Energy Back",
                desc: "Stop leaking your self-worth into a void. Reclaim your time."
              },
              {
                title: "Feel Grounded Again",
                desc: "Wake up without that heavy feeling in your chest."
              }
            ].map((feature, i) => (
              <div key={i} className="bg-slate-800 p-6 rounded border border-slate-700 shadow-lg">
                <h3 className="text-xl font-bold mb-2 text-slate-100">{feature.title}</h3>
                <p className="text-slate-300">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 6. WHO THIS IS FOR / NOT FOR */}
      <section className="py-20 px-6 max-w-4xl mx-auto bg-slate-50 relative z-10">
        <div className="grid md:grid-cols-2 gap-12">
          <div>
            <h3 className="text-xl font-bold mb-6 flex items-center gap-2 text-slate-900">
              <div className="bg-emerald-100 p-1 rounded text-emerald-800"><Check className="w-5 h-5" /></div>
              This Is For You If:
            </h3>
            <ul className="space-y-4 text-slate-700">
              <li>You feel intellectually smart but emotionally stupid right now.</li>
              <li>You are tired of bothering your friends with the same story.</li>
              <li>You want a direct, actionable solution, not a shoulder to cry on.</li>
            </ul>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-6 flex items-center gap-2 text-slate-900">
              <div className="bg-slate-200 p-1 rounded text-slate-700"><X className="w-5 h-5" /></div>
              This Is NOT For You If:
            </h3>
            <ul className="space-y-4 text-slate-700">
              <li>You are trying to "win them back" using mind games.</li>
              <li>You want to wallow in victimhood.</li>
              <li>You aren't ready to let go of the pain yet.</li>
            </ul>
          </div>
        </div>
      </section>

      {/* 7. OBJECTION HANDLING (FAQ) */}
      <section className="py-16 bg-white px-6 relative z-10 border-t border-slate-200">
        <div className="max-w-2xl mx-auto space-y-8">
          <h2 className="text-3xl font-serif font-bold text-center mb-10 text-slate-900">Common Questions</h2>
          
          <div className="bg-slate-50 p-6 rounded shadow-sm border border-slate-100">
            <h4 className="font-bold text-lg mb-2 text-slate-800">"I've tried everything. Why is this different?"</h4>
            <p className="text-slate-600">Most advice tells you to distract yourself. That’s avoidance. This protocol teaches you how to process the emotion so it leaves your body, rather than pushing it down.</p>
          </div>

          <div className="bg-slate-50 p-6 rounded shadow-sm border border-slate-100">
            <h4 className="font-bold text-lg mb-2 text-slate-800">"I don't want to become a cold person."</h4>
            <p className="text-slate-600">You won't. You will become a <em>stable</em> person. Detachment isn't about not feeling; it's about not being controlled by your feelings.</p>
          </div>

          <div className="bg-slate-50 p-6 rounded shadow-sm border border-slate-100">
            <h4 className="font-bold text-lg mb-2 text-slate-800">"Why is this $7 instead of $47?"</h4>
            <p className="text-slate-600">I want to remove every barrier between you and relief. At $47, you might hesitate. At $7, you can start immediately without overthinking it. I want you to have the solution today, not later.</p>
          </div>

          <div className="bg-slate-50 p-6 rounded shadow-sm border border-slate-100">
            <h4 className="font-bold text-lg mb-2 text-slate-800">"What if it doesn't work for me?"</h4>
            <p className="text-slate-600">The protocol is based on human psychology, not magic. If you do the exercises, your perspective <em>will</em> shift. It’s mechanics, not luck.</p>
          </div>
        </div>
      </section>

      {/* 8. FINAL CTA */}
      <section id="pricing" className="py-24 px-6 text-center max-w-3xl mx-auto relative z-10">
        <div className="bg-white/95 backdrop-blur p-8 md:p-12 rounded-2xl shadow-2xl border border-slate-200">
          <h2 className="text-4xl font-serif font-bold mb-6 text-slate-900">Stop The Cycle Today</h2>
          
          <p className="text-xl text-slate-600 mb-8">
            You don't have to wait for "time" to heal you. You can start the recovery process in the next 5 minutes.
          </p>
          
          <div className="flex items-center justify-center gap-4 mb-4">
            <span className="text-3xl text-slate-400 line-through decoration-slate-400/50">$47</span>
            <span className="text-6xl font-bold text-slate-900 tracking-tight">$7</span>
          </div>

          <p className="text-sm text-slate-400 mb-8 uppercase tracking-wide">One-time payment • Secure checkout</p>

          <Button 
            fullWidth 
            className="text-xl py-6 mb-4 shadow-xl shadow-slate-200/50"
            href={PAYMENT_LINK}
          >
            Get Instant Access
          </Button>

          <div className="flex justify-center items-center gap-2 mb-6">
            <span className="text-xs text-slate-400 uppercase tracking-wide">Secure Checkout via</span>
            <img 
              src="https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg" 
              alt="PayPal" 
              className="h-5 opacity-70 grayscale hover:grayscale-0 hover:opacity-100 transition-all"
            />
          </div>
          
          <div className="flex flex-col sm:flex-row justify-center items-center gap-4 sm:gap-8 text-xs text-slate-400 mt-6">
            <span className="flex items-center gap-1"><Lock className="w-3 h-3" /> 256-bit Secure SSL</span>
            <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> Instant PDF Download</span>
            <span className="flex items-center gap-1"><Shield className="w-3 h-3" /> 100% Data Privacy</span>
          </div>
        </div>
      </section>

      <footer className="py-12 text-center text-slate-500 text-sm bg-slate-900 border-t border-slate-800 relative z-10">
        <p>&copy; {new Date().getFullYear()} The Cure Protocol. All rights reserved.</p>
        <p className="mt-2">Not medical advice. If you are in crisis, please contact a professional.</p>
      </footer>
    </div>
  );
}

export default App;