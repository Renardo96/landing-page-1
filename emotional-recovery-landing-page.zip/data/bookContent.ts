export const bookTitle = "The Cure for Missing Someone Who Doesn’t Miss You";
export const bookSubtitle = "A fast emotional recovery protocol";

export const bookContent = [
  {
    title: "Introduction",
    text: `A fast emotional recovery protocol for people who are mentally stuck on someone who’s already gone — and paying for it with anxiety, obsession, and quiet self-destruction.

You might still care.
You might still hope.
You might still check your phone far too often.

And yet, deep down, you know something is wrong.

Emotional attachment becomes a problem when it starts robbing you of:
• Your peace
• Your confidence
• Your sense of control
• Your focus
• Your joy

Stoic philosophy teaches a powerful idea that changes everything:
You don’t control people. You control your response to people.

This guide will show you exactly how to emotionally detach — not by becoming cold, but by becoming calm.

By the end, you’ll know how to:
• Regain control over your thoughts
• Stop obsessing and replaying moments
• Pull your energy back from someone who drains you
• Feel lighter, grounded, and emotionally free again`
  },
  {
    title: "Step 1: Get Honest About the Attachment",
    text: `Detachment begins with truth.
Not just surface truth — emotional truth.

Take out a notebook or your phone and answer this:

• Who are you attached to?
• What do you wish were happening with this person?
• What is actually happening?
• How does this attachment affect your daily life?

Maybe you:
• Overthink every message.
• Re-read old conversations.
• Analyze social media posts.
• Constantly wonder what they’re thinking.
• Struggle to sleep because your mind won't shut off.

Now write this sentence and commit to it:
"I am starting a new chapter where I choose peace over attachment."

This isn’t about denying feelings.
It’s about refusing to let them run your life.`
  },
  {
    title: "Step 2: Learn the One Rule That Creates Instant Emotional Freedom",
    text: `Stoicism is built on one life-changing principle:
Separate what you control from what you don’t.

You do NOT control:
• How someone feels
• Whether they stay or leave
• Whether they text you
• Whether they change
• What others think of you

You DO control:
• Where your attention goes
• How you speak to yourself
• What thoughts you entertain
• How you spend your time
• Your self-respect

When you focus on things outside your control, suffering multiplies.
When you focus on what is yours to control, peace grows.

Start practicing one mantra:
"If it’s not mine to control, it’s not mine to carry."

Repeat this every time your mind spirals.`
  },
  {
    title: "Step 3: Pull Your Attention Back",
    text: `(Because Attention = Attachment)

Most emotional attachment isn’t emotional. It’s mental.
Your mind keeps returning to the same person, the same story, the same hope.

Detachment begins when you take your attention back.

Start with simple rules for at least two weeks:
• Stop checking their social media.
• Stop scrolling old messages.
• Stop rereading conversations.
• Stop “just checking in.”
• Stop chasing clarity from someone who’s confusing you.

You’re not doing this to punish them.
You’re doing it to protect yourself.

Then replace what you remove. Fill your days intentionally:
• Move your body.
• Read something that strengthens you.
• Watch videos that motivate you.
• Build a new skill.
• Journal.
• Improve your finances.
• Improve your health.
• Improve your confidence.

When your life grows, attachment shrinks.`
  },
  {
    title: "Step 4: Train Your Brain Using Stoic Thinking",
    text: `Attachment isn’t just to people — it’s to thoughts.
Every emotional wound repeats the same lies:
• “I’m not enough.”
• “I’ll never find better.”
• “They were special.”
• “I ruined everything.”

Write down the exact thought that hurts most.
Then ask:
• Is this fact… or fear?
• Is this proof… or panic?
• Would a calm, wise version of me believe this?

Replace the thought with something grounded:
• “I don’t control how they feel, but I control how I heal.”
• “I don’t chase people who choose distance.”
• “I am allowed to move on without permission.”
• “Someone leaving does not mean I am unlovable.”

You aren’t forcing positivity.
You’re choosing accuracy.`
  },
  {
    title: "Step 5: Build a Life That Doesn’t Depend on One Person",
    text: `Detachment sticks when your life becomes more meaningful than your memory.

Ask yourself:
• Who do I want to become because of this?
• What kind of life would make me proud a year from now?
• What would my future self thank me for building today?

Choose values:
• Peace
• Growth
• Responsibility
• Self-respect
• Courage
• Independence

Then act on them daily.
You don’t think your way into confidence.
You live your way into it.`
  },
  {
    title: "Step 6: Use These Mental Scripts When You Feel Weak",
    text: `When you want to reach out:
“I don’t chase what disrupts my peace.”

When you start checking their profile:
“I will not reopen emotional wounds for curiosity.”

When you miss them:
“Missing someone does not mean I should return to pain.”

When loneliness hits:
“Being alone is healthier than being emotionally starved.”

These aren’t affirmations.
They are emotional guardrails.`
  },
  {
    title: "Step 7: Measure Progress Instead of Chasing Perfection",
    text: `Detachment isn’t instant. It’s gradual clarity.
Each week, ask:

• Did I obsess less?
• Did I check in less?
• Did I react more calmly?
• Did I choose myself more?

Progress is not never thinking about them again.
Progress is:
Thinking about them… and not breaking down.

Final Truth:
Detaching doesn’t mean you never cared.
It means:
You care about your life more.

And the more you invest in yourself,
the less power anyone else has over your peace.`
  }
];